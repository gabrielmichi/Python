#!/usr/bin/env bash
/usr/bin/nohup /usr/local/hive/bin/hive --service hiveserver2 &
